const char * logl_root = "/Users/s.adams/Documents/GitHub/C-OpenGL-Metal-Work/Cross Platform Engine 2.0";
